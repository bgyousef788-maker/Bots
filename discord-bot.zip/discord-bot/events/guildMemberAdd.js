const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    // غير هذا إلى اسم أو ID قناة الترحيب عندك
    const welcomeChannel = member.guild.channels.cache.find(
      ch => ch.name === 'الترحيب' || ch.name === 'welcome'
    );

    if (!welcomeChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#00FF88')
      .setTitle(`🎉 أهلاً وسهلاً في ${member.guild.name}!`)
      .setDescription(
        `مرحباً ${member}! 🙌\nنورت السيرفر وعدد الأعضاء وصل **${member.guild.memberCount}** عضو!\n\nاقرأ القوانين وتمتع بوقتك معنا 🎮`
      )
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setImage('https://i.imgur.com/wSTFkRM.gif') // يمكنك تغيير الصورة
      .setFooter({ text: `معرف العضو: ${member.user.id}` })
      .setTimestamp();

    welcomeChannel.send({ content: `${member}`, embeds: [embed] });

    // إعطاء رول تلقائي للعضو الجديد
    const defaultRole = member.guild.roles.cache.find(r => r.name === 'عضو');
    if (defaultRole) {
      await member.roles.add(defaultRole).catch(() => {});
    }
  },
};
