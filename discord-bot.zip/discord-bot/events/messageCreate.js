const { EmbedBuilder } = require('discord.js');
const { addXP } = require('../utils/database');

const cooldowns = new Map();

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    // Cooldown 60 ثانية بين كل XP
    const key = `${message.author.id}-${message.guild.id}`;
    const now = Date.now();
    const cooldown = 60000;

    if (cooldowns.has(key) && now - cooldowns.get(key) < cooldown) return;
    cooldowns.set(key, now);

    const xpGain = Math.floor(Math.random() * 15) + 10; // 10-25 XP
    const { leveledUp, newLevel } = addXP(message.author.id, message.guild.id, xpGain);

    if (leveledUp) {
      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('⬆️ ارتفعت مستوى!')
        .setDescription(`تهانينا ${message.author}! وصلت للمستوى **${newLevel}** 🎉`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp();

      message.channel.send({ embeds: [embed] });
    }
  },
};
