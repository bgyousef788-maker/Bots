const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
} = require('discord.js');
const {
  getShopConfig, getSeller, isSeller,
  createProduct, getProduct, updateProduct, getSellerProducts,
  createOffer,
  createDeal, getDeal, getDealByTicket, closeDeal,
  createReview, getSellerRating,
  addBuyerPoints, getBuyerPoints, getBuyerLeaderboard,
} = require('../utils/database');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    // ======= SLASH COMMANDS =======
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      const { cooldowns } = client;
      if (!cooldowns.has(command.data.name)) cooldowns.set(command.data.name, new Map());
      const now = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const cooldownAmount = (command.cooldown || 3) * 1000;

      if (timestamps.has(interaction.user.id)) {
        const expiry = timestamps.get(interaction.user.id) + cooldownAmount;
        if (now < expiry) {
          const remaining = ((expiry - now) / 1000).toFixed(1);
          return interaction.reply({ content: `⏳ انتظر **${remaining}** ثانية.`, ephemeral: true });
        }
      }
      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error(error);
        const msg = { content: '❌ حدث خطأ!', ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(msg);
        else await interaction.reply(msg);
      }
      return;
    }

    // ======= MODALS =======
    if (interaction.isModalSubmit()) {
      const config = getShopConfig(interaction.guild.id);

      // --- نشر منتج ---
      if (interaction.customId === 'modal_post_product') {
        await interaction.deferReply({ ephemeral: true });
        const seller = getSeller(interaction.user.id, interaction.guild.id);
        const isVip = seller?.type === 'vip';

        const name = interaction.fields.getTextInputValue('product_name');
        const price = parseFloat(interaction.fields.getTextInputValue('product_price'));
        const description = interaction.fields.getTextInputValue('product_description');
        const delivery = interaction.fields.getTextInputValue('product_delivery');
        const image = interaction.fields.getTextInputValue('product_image') || null;

        if (isNaN(price)) return interaction.editReply('❌ السعر يجب أن يكون رقماً!');

        const result = createProduct(interaction.guild.id, interaction.user.id, { name, price, description, delivery, image, stock: -1 });
        const productId = result.lastInsertRowid;
        const rating = getSellerRating(interaction.user.id, interaction.guild.id);
        const starsText = rating.avg > 0 ? '⭐'.repeat(Math.round(rating.avg)) + ` (${rating.avg}/5)` : 'جديد ✨';

        const channelId = isVip ? config.channel_vip : config.channel_normal;
        const channel = interaction.guild.channels.cache.get(channelId);
        if (!channel) return interaction.editReply('❌ روم النشر غير موجود! راجع الإعدادات.');

        const embed = new EmbedBuilder()
          .setColor(isVip ? '#FFD700' : '#5865F2')
          .setTitle(`${isVip ? '💎' : '🟡'} ${name}`)
          .setDescription(description)
          .addFields(
            { name: '💰 السعر', value: `${price} ريال`, inline: true },
            { name: '🚚 طريقة التسليم', value: delivery, inline: true },
            { name: '👤 البائع', value: `<@${interaction.user.id}>`, inline: true },
            { name: '⭐ تقييم البائع', value: starsText, inline: true },
            { name: '🆔 رقم المنتج', value: `#${productId}`, inline: true },
          )
          .setFooter({ text: isVip ? 'بائع موثق VIP 💎' : 'بائع عادي 🟡' })
          .setTimestamp();

        if (image) embed.setImage(image);

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`buy_product_${productId}`)
            .setLabel('🛒 شراء الآن')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`product_info_${productId}`)
            .setLabel('ℹ️ مزيد من المعلومات')
            .setStyle(ButtonStyle.Secondary),
        );

        const msg = await channel.send({ embeds: [embed], components: [row] });
        updateProduct(productId, { message_id: msg.id, channel_id: channel.id });

        return interaction.editReply(`✅ تم نشر منتجك **${name}** في ${channel}!`);
      }

      // --- نشر عرض ---
      if (interaction.customId === 'modal_post_offer') {
        await interaction.deferReply({ ephemeral: true });
        const seller = getSeller(interaction.user.id, interaction.guild.id);
        const isVip = seller?.type === 'vip';

        const title = interaction.fields.getTextInputValue('offer_title');
        const description = interaction.fields.getTextInputValue('offer_description');
        const originalPrice = parseFloat(interaction.fields.getTextInputValue('offer_original_price')) || null;
        const offerPrice = parseFloat(interaction.fields.getTextInputValue('offer_price'));
        const expiresAt = interaction.fields.getTextInputValue('offer_expires') || null;

        const discount = originalPrice ? Math.round((1 - offerPrice / originalPrice) * 100) : null;
        const result = createOffer(interaction.guild.id, interaction.user.id, { title, description, originalPrice, offerPrice, expiresAt });
        const offerId = result.lastInsertRowid;

        const channel = interaction.guild.channels.cache.get(config.channel_offers);
        if (!channel) return interaction.editReply('❌ روم العروض غير محدد!');

        const embed = new EmbedBuilder()
          .setColor('#FF6B35')
          .setTitle(`🔥 عرض خاص: ${title}`)
          .setDescription(description)
          .addFields(
            { name: '💰 السعر الأصلي', value: originalPrice ? `~~${originalPrice} ريال~~` : 'غير محدد', inline: true },
            { name: '🤑 سعر العرض', value: `**${offerPrice} ريال**`, inline: true },
            { name: '📉 نسبة الخصم', value: discount ? `**${discount}%** 🔥` : 'غير محدد', inline: true },
            { name: '👤 البائع', value: `<@${interaction.user.id}>`, inline: true },
            { name: '⏰ ينتهي', value: expiresAt || 'غير محدد', inline: true },
            { name: '🆔 رقم العرض', value: `#${offerId}`, inline: true },
          )
          .setFooter({ text: isVip ? 'بائع موثق VIP 💎' : 'بائع عادي 🟡' })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`contact_seller_${interaction.user.id}`)
            .setLabel('📩 تواصل مع البائع')
            .setStyle(ButtonStyle.Primary),
        );

        await channel.send({ embeds: [embed], components: [row] });
        return interaction.editReply(`✅ تم نشر عرضك **${title}** في ${channel}!`);
      }

      // --- تعديل منتج ---
      if (interaction.customId.startsWith('modal_edit_product_')) {
        await interaction.deferReply({ ephemeral: true });
        const productId = interaction.customId.split('_').pop();
        const product = getProduct(productId);

        if (!product || product.seller_id !== interaction.user.id) {
          return interaction.editReply('❌ لا يمكنك تعديل هذا المنتج!');
        }

        const name = interaction.fields.getTextInputValue('edit_name') || product.name;
        const price = parseFloat(interaction.fields.getTextInputValue('edit_price')) || product.price;
        const description = interaction.fields.getTextInputValue('edit_description') || product.description;
        const delivery = interaction.fields.getTextInputValue('edit_delivery') || product.delivery_method;

        updateProduct(productId, { name, price, description, delivery_method: delivery });

        // تعديل الرسالة المنشورة
        if (product.message_id && product.channel_id) {
          const channel = interaction.guild.channels.cache.get(product.channel_id);
          if (channel) {
            const msg = await channel.messages.fetch(product.message_id).catch(() => null);
            if (msg) {
              const seller = getSeller(interaction.user.id, interaction.guild.id);
              const isVip = seller?.type === 'vip';
              const rating = getSellerRating(interaction.user.id, interaction.guild.id);
              const starsText = rating.avg > 0 ? '⭐'.repeat(Math.round(rating.avg)) + ` (${rating.avg}/5)` : 'جديد ✨';

              const embed = new EmbedBuilder()
                .setColor(isVip ? '#FFD700' : '#5865F2')
                .setTitle(`${isVip ? '💎' : '🟡'} ${name} *(تم التعديل)*`)
                .setDescription(description)
                .addFields(
                  { name: '💰 السعر', value: `${price} ريال`, inline: true },
                  { name: '🚚 التسليم', value: delivery, inline: true },
                  { name: '👤 البائع', value: `<@${interaction.user.id}>`, inline: true },
                  { name: '⭐ تقييم البائع', value: starsText, inline: true },
                  { name: '🆔 رقم المنتج', value: `#${productId}`, inline: true },
                )
                .setFooter({ text: '✏️ تم التعديل' })
                .setTimestamp();

              await msg.edit({ embeds: [embed] });
            }
          }
        }

        return interaction.editReply('✅ تم تعديل المنتج بنجاح!');
      }

      // --- تقييم بائع ---
      if (interaction.customId.startsWith('modal_review_')) {
        await interaction.deferReply({ ephemeral: true });
        const parts = interaction.customId.split('_');
        const dealId = parts[2];
        const sellerId = parts[3];

        const stars = parseInt(interaction.fields.getTextInputValue('review_stars'));
        const comment = interaction.fields.getTextInputValue('review_comment');

        if (stars < 1 || stars > 5) return interaction.editReply('❌ النجوم يجب أن تكون بين 1 و 5!');

        const deal = getDeal(dealId);
        if (!deal) return interaction.editReply('❌ الصفقة غير موجودة!');

        createReview(interaction.guild.id, dealId, interaction.user.id, sellerId, stars, comment);

        // إرسال للروم تقييمات
        const config = getShopConfig(interaction.guild.id);
        const reviewChannel = interaction.guild.channels.cache.get(config?.channel_reviews);
        const sellerUser = await interaction.client.users.fetch(sellerId).catch(() => null);
        const starsEmoji = '⭐'.repeat(stars) + '☆'.repeat(5 - stars);

        if (reviewChannel) {
          const embed = new EmbedBuilder()
            .setColor(stars >= 4 ? '#00FF88' : stars >= 3 ? '#FFA500' : '#FF4444')
            .setTitle('⭐ تقييم جديد!')
            .addFields(
              { name: '👤 البائع', value: sellerUser ? `<@${sellerId}>` : sellerId, inline: true },
              { name: '🛒 المشتري', value: `<@${interaction.user.id}>`, inline: true },
              { name: '⭐ التقييم', value: `${starsEmoji} (${stars}/5)`, inline: true },
              { name: '📦 المنتج', value: deal.product_name, inline: true },
              { name: '💰 السعر', value: `${deal.price} ريال`, inline: true },
              { name: '💬 التعليق', value: comment || 'لا يوجد تعليق' },
            )
            .setTimestamp();

          await reviewChannel.send({ embeds: [embed] });
        }

        // نقاط للمشتري
        const buyerData = addBuyerPoints(interaction.user.id, interaction.guild.id, 1);

        // رتبة عميل
        if (buyerData.total_deals === 1 && config?.role_buyer) {
          const buyerRole = interaction.guild.roles.cache.get(config.role_buyer);
          const member = interaction.guild.members.cache.get(interaction.user.id);
          if (buyerRole && member) await member.roles.add(buyerRole).catch(() => {});
        }

        // رتبة كبار الزبائن
        const topPoints = config?.top_buyer_points ?? 50;
        if (buyerData.points >= topPoints && config?.role_top_buyer) {
          const topRole = interaction.guild.roles.cache.get(config.role_top_buyer);
          const member = interaction.guild.members.cache.get(interaction.user.id);
          if (topRole && member) await member.roles.add(topRole).catch(() => {});
        }

        // تحديث مراتب الزبائن
        await updateBuyerRanks(interaction.guild, config, client);

        return interaction.editReply(`✅ تم إرسال تقييمك! حصلت على نقطة 🎯 (إجمالي: **${buyerData.points}** نقطة)`);
      }

      return;
    }

    // ======= BUTTONS =======
    if (interaction.isButton()) {
      const config = getShopConfig(interaction.guild.id);

      // --- فتح موديل نشر منتج ---
      if (interaction.customId === 'seller_post_product') {
        if (!isSeller(interaction.user.id, interaction.guild.id)) {
          return interaction.reply({ content: '❌ أنت لست بائعاً!', ephemeral: true });
        }

        const modal = new ModalBuilder()
          .setCustomId('modal_post_product')
          .setTitle('📦 نشر منتج جديد');

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('product_name').setLabel('اسم المنتج').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('product_price').setLabel('السعر (بالريال)').setStyle(TextInputStyle.Short).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('product_description').setLabel('الوصف').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(500)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('product_delivery').setLabel('طريقة التسليم').setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder('مثال: يدوي عبر الخاص، أو تلقائي')
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('product_image').setLabel('رابط الصورة (اختياري)').setStyle(TextInputStyle.Short).setRequired(false)
          ),
        );

        return interaction.showModal(modal);
      }

      // --- فتح موديل نشر عرض ---
      if (interaction.customId === 'seller_post_offer') {
        if (!isSeller(interaction.user.id, interaction.guild.id)) {
          return interaction.reply({ content: '❌ أنت لست بائعاً!', ephemeral: true });
        }

        const modal = new ModalBuilder()
          .setCustomId('modal_post_offer')
          .setTitle('🏷️ نشر عرض خاص');

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('offer_title').setLabel('عنوان العرض').setStyle(TextInputStyle.Short).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('offer_description').setLabel('وصف العرض').setStyle(TextInputStyle.Paragraph).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('offer_original_price').setLabel('السعر الأصلي (اختياري)').setStyle(TextInputStyle.Short).setRequired(false)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('offer_price').setLabel('سعر العرض').setStyle(TextInputStyle.Short).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('offer_expires').setLabel('تاريخ انتهاء العرض (اختياري)').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('مثال: 2024-12-31')
          ),
        );

        return interaction.showModal(modal);
      }

      // --- منتجاتي ---
      if (interaction.customId === 'seller_my_products') {
        const products = getSellerProducts(interaction.user.id, interaction.guild.id);
        if (!products.length) return interaction.reply({ content: '📦 ليس لديك منتجات نشطة.', ephemeral: true });

        const embed = new EmbedBuilder()
          .setColor('#5865F2')
          .setTitle('📋 منتجاتي')
          .setDescription(products.map(p => `**#${p.id}** ${p.name} — ${p.price} ريال`).join('\n'))
          .setTimestamp();

        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // --- إحصائياتي ---
      if (interaction.customId === 'seller_stats') {
        const rating = getSellerRating(interaction.user.id, interaction.guild.id);
        const products = getSellerProducts(interaction.user.id, interaction.guild.id);
        const seller = getSeller(interaction.user.id, interaction.guild.id);
        const starsText = rating.avg > 0 ? '⭐'.repeat(Math.round(rating.avg)) + ` (${rating.avg}/5)` : 'لا يوجد تقييم بعد';

        const embed = new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('📊 إحصائياتي')
          .addFields(
            { name: '📦 منتجات نشطة', value: `${products.length}`, inline: true },
            { name: '🤝 صفقات ناجحة', value: `${rating.total_sales}`, inline: true },
            { name: '⭐ التقييم', value: starsText, inline: true },
          )
          .setTimestamp();

        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // --- تعديل منتج ---
      if (interaction.customId === 'seller_edit_product') {
        const products = getSellerProducts(interaction.user.id, interaction.guild.id);
        if (!products.length) return interaction.reply({ content: '❌ ليس لديك منتجات لتعديلها.', ephemeral: true });

        const options = products.slice(0, 25).map(p => ({
          label: p.name.slice(0, 50),
          description: `${p.price} ريال`,
          value: String(p.id),
        }));

        const row = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('select_edit_product')
            .setPlaceholder('اختر المنتج للتعديل')
            .addOptions(options)
        );

        return interaction.reply({ content: '📋 اختر المنتج الذي تريد تعديله:', components: [row], ephemeral: true });
      }

      // --- شراء منتج (فتح تكت) ---
      if (interaction.customId.startsWith('buy_product_')) {
        const productId = interaction.customId.split('_')[2];
        const product = getProduct(productId);

        if (!product || product.status !== 'active') {
          return interaction.reply({ content: '❌ هذا المنتج غير متاح!', ephemeral: true });
        }

        if (product.seller_id === interaction.user.id) {
          return interaction.reply({ content: '❌ لا يمكنك شراء منتجك الخاص!', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        // إنشاء تكت
        const ticketChannel = await interaction.guild.channels.create({
          name: `صفقة-${interaction.user.username}-${productId}`,
          type: ChannelType.GuildText,
          permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
            { id: product.seller_id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
            { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
          ],
          topic: `صفقة بين ${interaction.user.tag} والبائع | المنتج: ${product.name}`,
        });

        const dealResult = createDeal(interaction.guild.id, productId, interaction.user.id, product.seller_id, product.name, product.price, ticketChannel.id);
        const dealId = dealResult.lastInsertRowid;

        const embed = new EmbedBuilder()
          .setColor('#00FF88')
          .setTitle('🛒 تكت شراء جديد!')
          .setDescription(`مرحباً! تم فتح هذا التكت لإتمام صفقة شراء.`)
          .addFields(
            { name: '📦 المنتج', value: product.name, inline: true },
            { name: '💰 السعر', value: `${product.price} ريال`, inline: true },
            { name: '🚚 التسليم', value: product.delivery_method || 'غير محدد', inline: true },
            { name: '🛒 المشتري', value: `<@${interaction.user.id}>`, inline: true },
            { name: '👤 البائع', value: `<@${product.seller_id}>`, inline: true },
            { name: '🆔 رقم الصفقة', value: `#${dealId}`, inline: true },
          )
          .setFooter({ text: 'بعد إتمام الصفقة، اضغط "إغلاق وتقييم"' })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`close_deal_${dealId}_${product.seller_id}`)
            .setLabel('✅ إغلاق وتقييم البائع')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`cancel_deal_${dealId}`)
            .setLabel('❌ إلغاء')
            .setStyle(ButtonStyle.Danger),
        );

        await ticketChannel.send({
          content: `<@${interaction.user.id}> <@${product.seller_id}>`,
          embeds: [embed],
          components: [row],
        });

        return interaction.editReply(`✅ تم فتح التكت: ${ticketChannel}`);
      }

      // --- إغلاق الصفقة وتقييم ---
      if (interaction.customId.startsWith('close_deal_')) {
        const parts = interaction.customId.split('_');
        const dealId = parts[2];
        const sellerId = parts[3];

        const deal = getDeal(dealId);
        if (!deal) return interaction.reply({ content: '❌ الصفقة غير موجودة!', ephemeral: true });
        if (deal.buyer_id !== interaction.user.id) {
          return interaction.reply({ content: '❌ فقط المشتري يمكنه إغلاق الصفقة!', ephemeral: true });
        }

        // موديل التقييم
        const modal = new ModalBuilder()
          .setCustomId(`modal_review_${dealId}_${sellerId}`)
          .setTitle('⭐ تقييم البائع');

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('review_stars')
              .setLabel('التقييم (1-5 نجوم)')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setPlaceholder('اكتب رقم من 1 إلى 5')
              .setMaxLength(1)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('review_comment')
              .setLabel('تعليقك (اختياري)')
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(false)
              .setMaxLength(300)
          ),
        );

        closeDeal(dealId);
        return interaction.showModal(modal);
      }

      // --- إلغاء الصفقة ---
      if (interaction.customId.startsWith('cancel_deal_')) {
        const dealId = interaction.customId.split('_')[2];
        const deal = getDeal(dealId);

        if (!deal) return interaction.reply({ content: '❌ الصفقة غير موجودة!', ephemeral: true });
        if (deal.buyer_id !== interaction.user.id && deal.seller_id !== interaction.user.id) {
          return interaction.reply({ content: '❌ ليس لديك صلاحية!', ephemeral: true });
        }

        await interaction.reply({ content: '🗑️ جاري إغلاق التكت...', ephemeral: false });
        setTimeout(() => interaction.channel.delete().catch(() => {}), 3000);
      }

      // --- تواصل مع البائع (من عرض) ---
      if (interaction.customId.startsWith('contact_seller_')) {
        const sellerId = interaction.customId.split('_')[2];
        const seller = await interaction.client.users.fetch(sellerId).catch(() => null);
        return interaction.reply({
          content: `📩 تواصل مع البائع مباشرة: <@${sellerId}>${seller ? ` (${seller.tag})` : ''}`,
          ephemeral: true
        });
      }
    }

    // ======= SELECT MENU =======
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'select_edit_product') {
        const productId = interaction.values[0];
        const product = getProduct(productId);

        if (!product || product.seller_id !== interaction.user.id) {
          return interaction.reply({ content: '❌ لا يمكنك تعديل هذا المنتج!', ephemeral: true });
        }

        const modal = new ModalBuilder()
          .setCustomId(`modal_edit_product_${productId}`)
          .setTitle(`✏️ تعديل: ${product.name.slice(0, 30)}`);

        modal.addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('edit_name').setLabel('الاسم الجديد').setStyle(TextInputStyle.Short).setRequired(false).setValue(product.name)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('edit_price').setLabel('السعر الجديد').setStyle(TextInputStyle.Short).setRequired(false).setValue(String(product.price))
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('edit_description').setLabel('الوصف الجديد').setStyle(TextInputStyle.Paragraph).setRequired(false).setValue(product.description || '')
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('edit_delivery').setLabel('طريقة التسليم').setStyle(TextInputStyle.Short).setRequired(false).setValue(product.delivery_method || '')
          ),
        );

        return interaction.showModal(modal);
      }
    }
  },
};

// ===== تحديث روم مراتب الزبائن =====
async function updateBuyerRanks(guild, config, client) {
  if (!config?.channel_buyer_ranks) return;
  const channel = guild.channels.cache.get(config.channel_buyer_ranks);
  if (!channel) return;

  const { getBuyerLeaderboard } = require('../utils/database');
  const leaders = getBuyerLeaderboard(guild.id, 10);

  const medals = ['🥇', '🥈', '🥉'];
  const desc = await Promise.all(leaders.map(async (u, i) => {
    const user = await client.users.fetch(u.user_id).catch(() => null);
    const name = user ? user.username : `User`;
    const medal = medals[i] || `**${i + 1}.**`;
    return `${medal} **${name}** — 🎯 ${u.points} نقطة | 🤝 ${u.total_deals} صفقة`;
  }));

  const embed = new EmbedBuilder()
    .setColor('#FFD700')
    .setTitle('🏆 مراتب الزبائن')
    .setDescription(desc.join('\n') || 'لا يوجد زبائن بعد!')
    .setFooter({ text: 'يتحدث تلقائياً بعد كل صفقة ناجحة' })
    .setTimestamp();

  // حذف آخر رسالة وإرسال جديدة
  const messages = await channel.messages.fetch({ limit: 5 }).catch(() => null);
  if (messages) {
    const botMsgs = messages.filter(m => m.author.id === client.user.id);
    for (const msg of botMsgs.values()) await msg.delete().catch(() => {});
  }

  await channel.send({ embeds: [embed] });
}
