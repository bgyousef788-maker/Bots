const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getUser, calculateXPNeeded, getLeaderboard } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('عرض مستواك ونقاطك')
    .addUserOption(o => o.setName('العضو').setDescription('عضو معين (اختياري)')),

  async execute(interaction) {
    const target = interaction.options.getMember('العضو') || interaction.member;
    const user = getUser(target.user.id, interaction.guild.id);
    const xpNeeded = calculateXPNeeded(user.level);
    const progress = Math.floor((user.xp / xpNeeded) * 100);
    const progressBar = '█'.repeat(Math.floor(progress / 10)) + '░'.repeat(10 - Math.floor(progress / 10));

    const embed = new EmbedBuilder()
      .setColor('#7289DA')
      .setTitle(`📊 مستوى ${target.user.username}`)
      .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🏆 المستوى', value: `${user.level}`, inline: true },
        { name: '⚡ XP', value: `${user.xp} / ${xpNeeded}`, inline: true },
        { name: '💬 الرسائل', value: `${user.messages}`, inline: true },
        { name: '📈 التقدم', value: `\`${progressBar}\` ${progress}%` }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
