const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getLeaderboard } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('عرض قائمة أفضل الأعضاء'),

  async execute(interaction) {
    await interaction.deferReply();
    const leaders = getLeaderboard(interaction.guild.id, 10);

    const medals = ['🥇', '🥈', '🥉'];
    const description = leaders.map((u, i) => {
      const medal = medals[i] || `**${i + 1}.**`;
      const user = interaction.client.users.cache.get(u.user_id);
      const name = user ? user.username : `User ${u.user_id}`;
      return `${medal} **${name}** — المستوى ${u.level} | ${u.xp} XP`;
    }).join('\n');

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle('🏆 قائمة المتصدرين')
      .setDescription(description || 'لا يوجد بيانات بعد!')
      .setTimestamp();

    interaction.editReply({ embeds: [embed] });
  },
};
