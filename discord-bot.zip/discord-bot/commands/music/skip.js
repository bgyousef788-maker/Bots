// skip.js
const { SlashCommandBuilder } = require('discord.js');

const skipCommand = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('تخطي الأغنية الحالية'),

  async execute(interaction, client) {
    const queue = client.musicQueues.get(interaction.guild.id);
    if (!queue || !queue.playing) {
      return interaction.reply({ content: '❌ لا توجد موسيقى تعمل!', ephemeral: true });
    }
    queue.player.stop();
    interaction.reply('⏭️ تم تخطي الأغنية!');
  },
};

module.exports = skipCommand;
