const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
} = require('@discordjs/voice');
const play = require('play-dl');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('تشغيل أغنية من يوتيوب')
    .addStringOption(o => o.setName('الأغنية').setDescription('اسم الأغنية أو رابط يوتيوب').setRequired(true)),

  cooldown: 3,

  async execute(interaction, client) {
    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: '❌ يجب أن تكون في قناة صوتية!', ephemeral: true });
    }

    await interaction.deferReply();

    const query = interaction.options.getString('الأغنية');

    try {
      // البحث عن الأغنية
      const searchResult = await play.search(query, { limit: 1 });
      if (!searchResult || searchResult.length === 0) {
        return interaction.editReply('❌ لم يتم العثور على الأغنية!');
      }

      const song = searchResult[0];
      const guildId = interaction.guild.id;

      // إعداد القائمة
      if (!client.musicQueues.has(guildId)) {
        client.musicQueues.set(guildId, {
          connection: null,
          player: null,
          songs: [],
          playing: false,
        });
      }

      const queue = client.musicQueues.get(guildId);
      queue.songs.push({ title: song.title, url: song.url, duration: song.durationRaw, requester: interaction.user.tag });

      const embed = new EmbedBuilder()
        .setColor('#1DB954')
        .setTitle('🎵 تمت الإضافة للقائمة')
        .addFields(
          { name: 'الأغنية', value: `[${song.title}](${song.url})` },
          { name: 'المدة', value: song.durationRaw || 'غير معروف', inline: true },
          { name: 'الطالب', value: interaction.user.tag, inline: true },
          { name: 'الموضع في القائمة', value: `${queue.songs.length}`, inline: true }
        )
        .setThumbnail(song.thumbnails?.[0]?.url || null);

      await interaction.editReply({ embeds: [embed] });

      if (!queue.playing) {
        await startPlaying(queue, voiceChannel, interaction.guild, client);
      }
    } catch (err) {
      console.error(err);
      interaction.editReply('❌ حدث خطأ أثناء تشغيل الأغنية!');
    }
  },
};

async function startPlaying(queue, voiceChannel, guild, client) {
  if (queue.songs.length === 0) {
    queue.playing = false;
    if (queue.connection) queue.connection.destroy();
    return;
  }

  const song = queue.songs[0];
  queue.playing = true;

  try {
    const stream = await play.stream(song.url);
    const resource = createAudioResource(stream.stream, { inputType: stream.type });

    if (!queue.connection) {
      queue.connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
      });
    }

    if (!queue.player) {
      queue.player = createAudioPlayer();
      queue.connection.subscribe(queue.player);
    }

    queue.player.play(resource);

    queue.player.once(AudioPlayerStatus.Idle, () => {
      queue.songs.shift();
      startPlaying(queue, voiceChannel, guild, client);
    });

    queue.player.on('error', err => {
      console.error('Music error:', err);
      queue.songs.shift();
      startPlaying(queue, voiceChannel, guild, client);
    });
  } catch (err) {
    console.error(err);
    queue.songs.shift();
    startPlaying(queue, voiceChannel, guild, client);
  }
}
