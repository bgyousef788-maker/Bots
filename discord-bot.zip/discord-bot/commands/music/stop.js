const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('إيقاف الموسيقى ومسح القائمة'),

  async execute(interaction, client) {
    const queue = client.musicQueues.get(interaction.guild.id);
    if (!queue || !queue.playing) {
      return interaction.reply({ content: '❌ لا توجد موسيقى تعمل!', ephemeral: true });
    }

    queue.songs = [];
    queue.playing = false;
    queue.player?.stop();
    queue.connection?.destroy();
    client.musicQueues.delete(interaction.guild.id);

    interaction.reply('⏹️ تم إيقاف الموسيقى ومسح القائمة!');
  },
};
