const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('عرض قائمة الأغاني'),

  async execute(interaction, client) {
    const queue = client.musicQueues.get(interaction.guild.id);
    if (!queue || queue.songs.length === 0) {
      return interaction.reply({ content: '❌ القائمة فارغة!', ephemeral: true });
    }

    const songList = queue.songs
      .slice(0, 10)
      .map((s, i) => `${i === 0 ? '▶️' : `${i + 1}.`} **${s.title}** — ${s.duration} | ${s.requester}`)
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor('#1DB954')
      .setTitle('🎵 قائمة الأغاني')
      .setDescription(songList)
      .setFooter({ text: `${queue.songs.length} أغنية في القائمة` })
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
