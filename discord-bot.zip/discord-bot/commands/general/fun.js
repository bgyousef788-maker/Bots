const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

// /ping
const ping = {
  data: new SlashCommandBuilder().setName('ping').setDescription('يعطيك البينج'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 جاري القياس...', fetchReply: true });
    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    interaction.editReply(`🏓 **بينج:** ${latency}ms | **API:** ${interaction.client.ws.ping}ms`);
  },
};

// /userinfo
const userinfo = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('معلومات عن عضو')
    .addUserOption(o => o.setName('العضو').setDescription('العضو')),
  async execute(interaction) {
    const member = interaction.options.getMember('العضو') || interaction.member;
    const roles = member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r).join(', ') || 'لا يوجد';

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`👤 معلومات ${member.user.username}`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🏷️ الاسم', value: member.user.tag, inline: true },
        { name: '🆔 الآيدي', value: member.user.id, inline: true },
        { name: '📅 انضم للديسكورد', value: `<t:${Math.floor(member.user.createdAt / 1000)}:R>`, inline: true },
        { name: '📅 انضم للسيرفر', value: `<t:${Math.floor(member.joinedAt / 1000)}:R>`, inline: true },
        { name: `🎭 الرولات (${member.roles.cache.size - 1})`, value: roles }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};

// /serverinfo
const serverinfo = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('معلومات السيرفر'),
  async execute(interaction) {
    const guild = interaction.guild;
    await guild.members.fetch();

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`🏰 ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: '👑 المالك', value: `<@${guild.ownerId}>`, inline: true },
        { name: '👥 الأعضاء', value: `${guild.memberCount}`, inline: true },
        { name: '📅 أُنشئ', value: `<t:${Math.floor(guild.createdAt / 1000)}:R>`, inline: true },
        { name: '📢 القنوات', value: `${guild.channels.cache.size}`, inline: true },
        { name: '🎭 الرولات', value: `${guild.roles.cache.size}`, inline: true },
        { name: '😀 الإيموجي', value: `${guild.emojis.cache.size}`, inline: true }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};

// /coinflip
const coinflip = {
  data: new SlashCommandBuilder().setName('coinflip').setDescription('رمي العملة'),
  async execute(interaction) {
    const result = Math.random() < 0.5 ? '🦅 صورة' : '🪙 كتابة';
    interaction.reply(`${result}`);
  },
};

// /8ball
const eightball = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('اسأل كرة الحظ')
    .addStringOption(o => o.setName('السؤال').setDescription('سؤالك').setRequired(true)),
  async execute(interaction) {
    const answers = [
      '✅ نعم بالتأكيد!', '✅ بالطبع!', '✅ يبدو كذلك.', '✅ الجواب إيجابي.',
      '❓ ربما...', '❓ لا أعرف.', '❓ اسأل لاحقاً.',
      '❌ لا أعتقد.', '❌ بالتأكيد لا!', '❌ التوقعات سلبية.'
    ];
    const answer = answers[Math.floor(Math.random() * answers.length)];
    const question = interaction.options.getString('السؤال');

    const embed = new EmbedBuilder()
      .setColor('#7289DA')
      .setTitle('🎱 كرة الحظ')
      .addFields(
        { name: '❓ السؤال', value: question },
        { name: '🔮 الجواب', value: answer }
      );

    interaction.reply({ embeds: [embed] });
  },
};

// /avatar
const avatar = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('صورة بروفايل عضو')
    .addUserOption(o => o.setName('العضو').setDescription('العضو')),
  async execute(interaction) {
    const user = interaction.options.getUser('العضو') || interaction.user;
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`🖼️ صورة ${user.username}`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }));
    interaction.reply({ embeds: [embed] });
  },
};

module.exports = [ping, userinfo, serverinfo, coinflip, eightball, avatar];
