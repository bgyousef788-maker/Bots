const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('كتم عضو مؤقتاً')
    .addUserOption(o => o.setName('العضو').setDescription('العضو المراد كتمه').setRequired(true))
    .addIntegerOption(o => o.setName('المدة').setDescription('المدة بالدقائق').setRequired(true).setMinValue(1).setMaxValue(10080))
    .addStringOption(o => o.setName('السبب').setDescription('سبب الكتم'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  cooldown: 5,

  async execute(interaction) {
    const target = interaction.options.getMember('العضو');
    const duration = interaction.options.getInteger('المدة');
    const reason = interaction.options.getString('السبب') || 'لم يُذكر سبب';

    if (!target) return interaction.reply({ content: '❌ العضو غير موجود!', ephemeral: true });
    if (!target.moderatable) return interaction.reply({ content: '❌ لا أستطيع كتم هذا العضو!', ephemeral: true });

    await target.timeout(duration * 60 * 1000, reason);

    const embed = new EmbedBuilder()
      .setColor('#FFA500')
      .setTitle('🔇 تم الكتم')
      .addFields(
        { name: 'العضو', value: `${target.user.tag}`, inline: true },
        { name: 'المدة', value: `${duration} دقيقة`, inline: true },
        { name: 'المشرف', value: `${interaction.user.tag}`, inline: true },
        { name: 'السبب', value: reason }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
