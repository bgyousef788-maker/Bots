// commands/moderation/ban.js
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('حظر عضو من السيرفر')
    .addUserOption(o => o.setName('العضو').setDescription('العضو المراد حظره').setRequired(true))
    .addStringOption(o => o.setName('السبب').setDescription('سبب الحظر'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  cooldown: 5,

  async execute(interaction) {
    const target = interaction.options.getMember('العضو');
    const reason = interaction.options.getString('السبب') || 'لم يُذكر سبب';

    if (!target) return interaction.reply({ content: '❌ العضو غير موجود!', ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ content: '❌ لا تقدر تحظر نفسك!', ephemeral: true });
    if (!target.bannable) return interaction.reply({ content: '❌ لا أستطيع حظر هذا العضو!', ephemeral: true });

    await target.ban({ reason });

    const embed = new EmbedBuilder()
      .setColor('#FF0000')
      .setTitle('🔨 تم الحظر')
      .addFields(
        { name: 'العضو', value: `${target.user.tag}`, inline: true },
        { name: 'المشرف', value: `${interaction.user.tag}`, inline: true },
        { name: 'السبب', value: reason }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
