const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('طرد عضو من السيرفر')
    .addUserOption(o => o.setName('العضو').setDescription('العضو المراد طرده').setRequired(true))
    .addStringOption(o => o.setName('السبب').setDescription('سبب الطرد'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  cooldown: 5,

  async execute(interaction) {
    const target = interaction.options.getMember('العضو');
    const reason = interaction.options.getString('السبب') || 'لم يُذكر سبب';

    if (!target) return interaction.reply({ content: '❌ العضو غير موجود!', ephemeral: true });
    if (!target.kickable) return interaction.reply({ content: '❌ لا أستطيع طرد هذا العضو!', ephemeral: true });

    await target.kick(reason);

    const embed = new EmbedBuilder()
      .setColor('#FF6600')
      .setTitle('👢 تم الطرد')
      .addFields(
        { name: 'العضو', value: `${target.user.tag}`, inline: true },
        { name: 'المشرف', value: `${interaction.user.tag}`, inline: true },
        { name: 'السبب', value: reason }
      )
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
