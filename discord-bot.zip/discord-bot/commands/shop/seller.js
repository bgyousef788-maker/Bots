const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const {
  getShopConfig, isSeller, getSeller,
  createProduct, createOffer, getSellerProducts, getSellerRating,
} = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('seller')
    .setDescription('لوحة تحكم البائع')
    .addSubcommand(sub => sub.setName('panel').setDescription('فتح لوحة التحكم الخاصة بك'))
    .addSubcommand(sub => sub.setName('stats').setDescription('عرض إحصائياتك كبائع')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const config = getShopConfig(interaction.guild.id);

    if (!config?.enabled) {
      return interaction.reply({ content: '❌ نظام المتجر غير مفعّل في هذا السيرفر!', ephemeral: true });
    }

    if (!isSeller(interaction.user.id, interaction.guild.id)) {
      return interaction.reply({ content: '❌ أنت لست بائعاً مسجلاً! تواصل مع الإدارة.', ephemeral: true });
    }

    const seller = getSeller(interaction.user.id, interaction.guild.id);
    const isVip = seller.type === 'vip';

    // ===== STATS =====
    if (sub === 'stats') {
      const rating = getSellerRating(interaction.user.id, interaction.guild.id);
      const products = getSellerProducts(interaction.user.id, interaction.guild.id);
      const stars = rating.avg > 0 ? '⭐'.repeat(Math.round(rating.avg)) : 'لا يوجد تقييم بعد';

      const embed = new EmbedBuilder()
        .setColor(isVip ? '#FFD700' : '#5865F2')
        .setTitle(`${isVip ? '💎' : '🟡'} إحصائيات ${interaction.user.username}`)
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🏷️ نوع الحساب', value: isVip ? 'بائع موثق VIP 💎' : 'بائع عادي 🟡', inline: true },
          { name: '📦 منتجات نشطة', value: `${products.length}`, inline: true },
          { name: '🤝 صفقات ناجحة', value: `${rating.total_sales}`, inline: true },
          { name: '⭐ متوسط التقييم', value: `${rating.avg}/5 (${rating.count} تقييم)`, inline: true },
          { name: '🌟 النجوم', value: stars, inline: true },
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // ===== PANEL =====
    const embed = new EmbedBuilder()
      .setColor(isVip ? '#FFD700' : '#5865F2')
      .setTitle(`${isVip ? '💎 لوحة البائع الموثق' : '🟡 لوحة البائع'}`)
      .setDescription(
        `مرحباً **${interaction.user.username}**!\n\n` +
        `نوع حسابك: **${isVip ? 'بائع موثق VIP 💎' : 'بائع عادي 🟡'}**\n` +
        `منتجاتك ستُنشر في: ${isVip ? `<#${config.channel_vip}>` : `<#${config.channel_normal}>`}\n\n` +
        `اختر ما تريد القيام به:`
      )
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();

    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('seller_post_product')
        .setLabel('📦 نشر منتج')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('seller_post_offer')
        .setLabel('🏷️ نشر عرض')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('seller_my_products')
        .setLabel('📋 منتجاتي')
        .setStyle(ButtonStyle.Secondary),
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('seller_stats')
        .setLabel('📊 إحصائياتي')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('seller_edit_product')
        .setLabel('✏️ تعديل منتج')
        .setStyle(ButtonStyle.Danger),
    );

    return interaction.reply({ embeds: [embed], components: [row1, row2], ephemeral: true });
  },
};
