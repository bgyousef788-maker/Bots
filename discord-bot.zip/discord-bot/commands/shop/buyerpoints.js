const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBuyerPoints, getBuyerLeaderboard, getShopConfig } = require('../../utils/database');

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('mypoints')
      .setDescription('عرض نقاطك كزبون'),

    async execute(interaction) {
      const data = getBuyerPoints(interaction.user.id, interaction.guild.id);
      const config = getShopConfig(interaction.guild.id);
      const topPoints = config?.top_buyer_points ?? 50;
      const points = data?.points ?? 0;
      const deals = data?.total_deals ?? 0;
      const progress = Math.min(Math.floor((points / topPoints) * 100), 100);
      const bar = '█'.repeat(Math.floor(progress / 10)) + '░'.repeat(10 - Math.floor(progress / 10));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🎯 نقاطي كزبون')
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🎯 نقاطي', value: `${points}`, inline: true },
          { name: '🤝 صفقاتي', value: `${deals}`, inline: true },
          { name: '👑 نقاط رتبة الكبار', value: `${topPoints}`, inline: true },
          { name: '📈 التقدم نحو رتبة الكبار', value: `\`${bar}\` ${progress}%` },
        )
        .setTimestamp();

      interaction.reply({ embeds: [embed], ephemeral: true });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('buyerranks')
      .setDescription('عرض مراتب الزبائن'),

    async execute(interaction, client) {
      await interaction.deferReply();
      const leaders = getBuyerLeaderboard(interaction.guild.id, 10);

      if (!leaders.length) {
        return interaction.editReply('❌ لا يوجد زبائن بعد!');
      }

      const medals = ['🥇', '🥈', '🥉'];
      const desc = await Promise.all(leaders.map(async (u, i) => {
        const user = await client.users.fetch(u.user_id).catch(() => null);
        const name = user ? user.username : 'مجهول';
        const medal = medals[i] || `**${i + 1}.**`;
        return `${medal} **${name}** — 🎯 ${u.points} نقطة | 🤝 ${u.total_deals} صفقة`;
      }));

      const embed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('🏆 مراتب الزبائن')
        .setDescription(desc.join('\n'))
        .setFooter({ text: 'كل صفقة ناجحة = نقطة!' })
        .setTimestamp();

      interaction.editReply({ embeds: [embed] });
    },
  },
];
