const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelType,
  StringSelectMenuBuilder,
} = require('discord.js');
const { getShopConfig, setShopConfig, registerSeller } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup-shop')
    .setDescription('إعداد نظام المتجر الاحترافي')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub.setName('start')
        .setDescription('بدء إعداد المتجر - سيظهر لك بانل التهيئة الكاملة')
    )
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('عرض الإعدادات الحالية للمتجر')
    )
    .addSubcommand(sub =>
      sub.setName('addseller')
        .setDescription('إضافة بائع')
        .addUserOption(o => o.setName('العضو').setDescription('العضو').setRequired(true))
        .addStringOption(o =>
          o.setName('النوع').setDescription('نوع البائع').setRequired(true)
            .addChoices(
              { name: '🟡 بائع عادي', value: 'normal' },
              { name: '💎 بائع موثق VIP', value: 'vip' }
            )
        )
    )
    .addSubcommand(sub =>
      sub.setName('toggle')
        .setDescription('تفعيل أو تعطيل المتجر')
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const config = getShopConfig(interaction.guild.id);

    // ===== STATUS =====
    if (sub === 'status') {
      const embed = new EmbedBuilder()
        .setColor(config?.enabled ? '#00FF88' : '#FF4444')
        .setTitle('⚙️ إعدادات المتجر')
        .setDescription(config?.enabled ? '✅ المتجر **مفعّل**' : '❌ المتجر **معطّل**')
        .addFields(
          { name: '📢 روم البائع العادي', value: config?.channel_normal ? `<#${config.channel_normal}>` : '❌ غير محدد', inline: true },
          { name: '💎 روم البائع VIP', value: config?.channel_vip ? `<#${config.channel_vip}>` : '❌ غير محدد', inline: true },
          { name: '🏷️ روم العروض', value: config?.channel_offers ? `<#${config.channel_offers}>` : '❌ غير محدد', inline: true },
          { name: '🤝 روم الصفقات', value: config?.channel_deals ? `<#${config.channel_deals}>` : '❌ غير محدد', inline: true },
          { name: '⭐ روم التقييمات', value: config?.channel_reviews ? `<#${config.channel_reviews}>` : '❌ غير محدد', inline: true },
          { name: '🏆 روم مراتب الزبائن', value: config?.channel_buyer_ranks ? `<#${config.channel_buyer_ranks}>` : '❌ غير محدد', inline: true },
          { name: '🎭 رتبة بائع عادي', value: config?.role_seller ? `<@&${config.role_seller}>` : '❌ غير محددة', inline: true },
          { name: '💎 رتبة VIP', value: config?.role_vip_seller ? `<@&${config.role_vip_seller}>` : '❌ غير محددة', inline: true },
          { name: '🛒 رتبة عميل', value: config?.role_buyer ? `<@&${config.role_buyer}>` : '❌ غير محددة', inline: true },
          { name: '👑 رتبة كبار الزبائن', value: config?.role_top_buyer ? `<@&${config.role_top_buyer}>` : '❌ غير محددة', inline: true },
          { name: '🎯 نقاط رتبة الكبار', value: `${config?.top_buyer_points ?? 50} نقطة`, inline: true },
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // ===== TOGGLE =====
    if (sub === 'toggle') {
      if (!config) return interaction.reply({ content: '❌ أكمل الإعداد أولاً باستخدام `/setup-shop start`', ephemeral: true });
      setShopConfig(interaction.guild.id, { enabled: config.enabled ? 0 : 1 });
      return interaction.reply({
        content: config.enabled ? '❌ تم **تعطيل** المتجر.' : '✅ تم **تفعيل** المتجر!',
        ephemeral: true
      });
    }

    // ===== ADD SELLER =====
    if (sub === 'addseller') {
      const target = interaction.options.getMember('العضو');
      const type = interaction.options.getString('النوع');
      const cfg = getShopConfig(interaction.guild.id);

      registerSeller(target.user.id, interaction.guild.id, type);

      // إعطاء الرول المناسب
      const roleId = type === 'vip' ? cfg?.role_vip_seller : cfg?.role_seller;
      if (roleId) {
        const role = interaction.guild.roles.cache.get(roleId);
        if (role) await target.roles.add(role).catch(() => {});
      }

      const embed = new EmbedBuilder()
        .setColor(type === 'vip' ? '#FFD700' : '#5865F2')
        .setTitle(type === 'vip' ? '💎 تم تسجيل بائع VIP' : '🟡 تم تسجيل بائع عادي')
        .setDescription(`${target} أصبح الآن **${type === 'vip' ? 'بائع موثق VIP 💎' : 'بائع عادي 🟡'}**`)
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // ===== START SETUP =====
    if (sub === 'start') {
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('🛒 إعداد نظام المتجر الاحترافي')
        .setDescription(
          '**مرحباً بك في معالج إعداد المتجر!**\n\n' +
          'استخدم الأوامر التالية لإكمال الإعداد:\n\n' +
          '📢 `/setup-shop channels` — تحديد الرومات\n' +
          '🎭 `/setup-shop roles` — تحديد الرتب\n' +
          '🟢 `/setup-shop toggle` — تفعيل المتجر\n' +
          '👤 `/setup-shop addseller` — إضافة بائع\n\n' +
          '> ⚠️ يجب إكمال الرومات والرتب قبل التفعيل'
        )
        .addFields(
          { name: '🏪 الرومات المطلوبة', value: '• روم نشر منتجات البائع العادي\n• روم نشر منتجات VIP\n• روم العروض\n• روم الصفقات الناجحة\n• روم تقييم البائعين\n• روم مراتب الزبائن' },
          { name: '🎭 الرتب المطلوبة', value: '• رتبة بائع عادي\n• رتبة بائع VIP\n• رتبة عميل (بعد أول شراء)\n• رتبة كبار الزبائن' }
        )
        .setFooter({ text: 'نظام المتجر الاحترافي v2.0' })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('setup_channels')
          .setLabel('📢 إعداد الرومات')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('setup_roles')
          .setLabel('🎭 إعداد الرتب')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('setup_status')
          .setLabel('📊 عرض الإعدادات')
          .setStyle(ButtonStyle.Success),
      );

      return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
  },
};
