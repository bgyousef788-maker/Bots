const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

function loadCommands(client) {
  const commandsPath = path.join(__dirname, '../commands');
  const categories = fs.readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const commandFiles = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of commandFiles) {
      const commandExport = require(path.join(categoryPath, file));
      const commands = Array.isArray(commandExport) ? commandExport : [commandExport];
      for (const command of commands) {
        if (command.data && command.execute) {
          client.commands.set(command.data.name, command);
          console.log(`📌 تم تحميل الأمر: ${command.data.name}`);
        }
      }
    }
  }
}

async function deployCommands(client) {
  const commands = [];
  client.commands.forEach(cmd => commands.push(cmd.data.toJSON()));

  const rest = new REST().setToken(process.env.TOKEN);
  await rest.put(
    Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
    { body: commands }
  );
  console.log('✅ تم رفع الأوامر للسيرفر!');
}

module.exports = { loadCommands, deployCommands };
