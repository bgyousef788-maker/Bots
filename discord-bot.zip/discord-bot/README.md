# 🤖 بوت ديسكورد متكامل

## 📁 هيكل الملفات
```
discord-bot/
├── index.js                  # نقطة البداية
├── deploy-commands.js         # رفع الأوامر
├── .env                      # المتغيرات السرية
├── package.json
├── handlers/
│   ├── commandHandler.js
│   └── eventHandler.js
├── commands/
│   ├── general/
│   │   └── fun.js            # ping, userinfo, serverinfo, coinflip, 8ball, avatar
│   ├── moderation/
│   │   ├── ban.js
│   │   ├── kick.js
│   │   ├── mute.js
│   │   └── clear.js
│   ├── leveling/
│   │   ├── rank.js
│   │   └── leaderboard.js
│   ├── music/
│   │   ├── play.js
│   │   ├── skip.js
│   │   ├── stop.js
│   │   └── queue.js
│   └── shop/
│       ├── shop.js
│       ├── buy.js
│       └── admin.js
├── events/
│   ├── guildMemberAdd.js     # ترحيب بالأعضاء
│   ├── messageCreate.js      # نظام XP
│   └── interactionCreate.js  # معالج الأوامر
├── utils/
│   └── database.js           # قاعدة البيانات SQLite
└── data/
    └── database.db           # يُنشأ تلقائياً
```

---

## ⚙️ خطوات التثبيت

### 1️⃣ تثبيت Node.js
حمّل Node.js من: https://nodejs.org (النسخة 18 أو أحدث)

### 2️⃣ تثبيت المكتبات
```bash
npm install
```

### 3️⃣ إعداد ملف .env
افتح ملف `.env` وضع:
```
TOKEN=توكن_البوت
CLIENT_ID=آيدي_البوت
GUILD_ID=آيدي_السيرفر
```

**كيف تجيب هذه المعلومات؟**
- **TOKEN**: من [Discord Developer Portal](https://discord.com/developers/applications) ← Bot ← Reset Token
- **CLIENT_ID**: من نفس الصفحة ← General Information ← Application ID
- **GUILD_ID**: كليك يمين على اسم السيرفر في ديسكورد ← Copy Server ID

### 4️⃣ دعوة البوت للسيرفر
من Developer Portal ← OAuth2 ← URL Generator:
- اختر: `bot` + `applications.commands`
- Permissions: `Administrator`
- افتح الرابط وأضف البوت للسيرفر

### 5️⃣ رفع الأوامر
```bash
npm run deploy
```

### 6️⃣ تشغيل البوت
```bash
npm start
```
أو للتطوير مع إعادة تشغيل تلقائي:
```bash
npm run dev
```

---

## 🎮 قائمة الأوامر

### عامة
| الأمر | الوصف |
|-------|--------|
| `/ping` | قياس سرعة البوت |
| `/userinfo` | معلومات عضو |
| `/serverinfo` | معلومات السيرفر |
| `/avatar` | عرض صورة البروفايل |
| `/coinflip` | رمي العملة |
| `/8ball` | كرة الحظ |

### إدارة
| الأمر | الوصف |
|-------|--------|
| `/ban` | حظر عضو |
| `/kick` | طرد عضو |
| `/mute` | كتم عضو مؤقتاً |
| `/clear` | مسح رسائل |

### المستويات
| الأمر | الوصف |
|-------|--------|
| `/rank` | عرض مستواك |
| `/leaderboard` | قائمة المتصدرين |

### الموسيقى
| الأمر | الوصف |
|-------|--------|
| `/play` | تشغيل أغنية |
| `/skip` | تخطي الأغنية |
| `/stop` | إيقاف الموسيقى |
| `/queue` | عرض القائمة |

### المتجر
| الأمر | الوصف |
|-------|--------|
| `/shop` | عرض المنتجات |
| `/buy` | شراء منتج |
| `/admin addproduct` | إضافة منتج (أدمن) |
| `/admin orders` | عرض الطلبات (أدمن) |
| `/admin completeorder` | إتمام طلب (أدمن) |

---

## 🔧 تخصيص البوت

### تغيير قناة الترحيب
في `events/guildMemberAdd.js` عدّل:
```js
ch.name === 'الترحيب'
```

### تغيير قناة الطلبات
في `commands/shop/buy.js` عدّل:
```js
ch.name === 'الطلبات'
```

### إضافة رول تلقائي للأعضاء الجدد
في `events/guildMemberAdd.js` عدّل:
```js
r.name === 'عضو'
```

---

## ❓ مشاكل شائعة

**البوت لا يرد على الأوامر؟**
- تأكد أنك شغلت `npm run deploy` أولاً
- تأكد أن الـ GUILD_ID صحيح

**مشكلة في الموسيقى؟**
- تأكد من تثبيت `ffmpeg`:
  - Windows: حمّل من https://ffmpeg.org وأضفه لـ PATH
  - Linux: `sudo apt install ffmpeg`

**قاعدة البيانات لا تعمل؟**
- تأكد إنشاء مجلد `data/` يدوياً إذا لم يُنشأ تلقائياً
