const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '../data/database.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS levels (
    user_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 0,
    messages INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );

  CREATE TABLE IF NOT EXISTS shop_config (
    guild_id TEXT PRIMARY KEY,
    enabled INTEGER DEFAULT 0,
    channel_normal TEXT,
    channel_vip TEXT,
    channel_offers TEXT,
    channel_deals TEXT,
    channel_reviews TEXT,
    channel_buyer_ranks TEXT,
    role_seller TEXT,
    role_vip_seller TEXT,
    role_buyer TEXT,
    role_top_buyer TEXT,
    top_buyer_points INTEGER DEFAULT 50
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    seller_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    delivery_method TEXT,
    image_url TEXT,
    stock INTEGER DEFAULT -1,
    status TEXT DEFAULT 'active',
    message_id TEXT,
    channel_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS offers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    seller_id TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_price REAL,
    offer_price REAL NOT NULL,
    discount_percent INTEGER,
    image_url TEXT,
    expires_at TEXT,
    message_id TEXT,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS deals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    product_id INTEGER,
    buyer_id TEXT NOT NULL,
    seller_id TEXT NOT NULL,
    product_name TEXT NOT NULL,
    price REAL NOT NULL,
    ticket_channel_id TEXT,
    status TEXT DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    closed_at DATETIME
  );

  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    deal_id INTEGER NOT NULL,
    reviewer_id TEXT NOT NULL,
    seller_id TEXT NOT NULL,
    stars INTEGER NOT NULL,
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS buyer_points (
    user_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    points INTEGER DEFAULT 0,
    total_deals INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );

  CREATE TABLE IF NOT EXISTS sellers (
    user_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    type TEXT DEFAULT 'normal',
    total_sales INTEGER DEFAULT 0,
    rating_sum INTEGER DEFAULT 0,
    rating_count INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );
`);

// ===== Levels =====
function getUser(userId, guildId) {
  let user = db.prepare('SELECT * FROM levels WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
  if (!user) {
    db.prepare('INSERT INTO levels (user_id, guild_id) VALUES (?, ?)').run(userId, guildId);
    user = db.prepare('SELECT * FROM levels WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
  }
  return user;
}

function addXP(userId, guildId, amount) {
  const user = getUser(userId, guildId);
  const newXP = user.xp + amount;
  const xpNeeded = calculateXPNeeded(user.level);
  let leveledUp = false;
  let newLevel = user.level;
  if (newXP >= xpNeeded) { newLevel = user.level + 1; leveledUp = true; }
  db.prepare('UPDATE levels SET xp = ?, level = ?, messages = messages + 1 WHERE user_id = ? AND guild_id = ?')
    .run(newXP >= xpNeeded ? newXP - xpNeeded : newXP, newLevel, userId, guildId);
  return { leveledUp, newLevel };
}

function calculateXPNeeded(level) { return 100 * (level + 1) * 1.5; }

function getLeaderboard(guildId, limit = 10) {
  return db.prepare('SELECT * FROM levels WHERE guild_id = ? ORDER BY level DESC, xp DESC LIMIT ?').all(guildId, limit);
}

// ===== Shop Config =====
function getShopConfig(guildId) {
  return db.prepare('SELECT * FROM shop_config WHERE guild_id = ?').get(guildId);
}

function setShopConfig(guildId, data) {
  const existing = getShopConfig(guildId);
  if (!existing) db.prepare('INSERT INTO shop_config (guild_id) VALUES (?)').run(guildId);
  const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
  db.prepare(`UPDATE shop_config SET ${fields} WHERE guild_id = ?`).run(...Object.values(data), guildId);
}

// ===== Products =====
function createProduct(guildId, sellerId, data) {
  return db.prepare(`
    INSERT INTO products (guild_id, seller_id, name, description, price, delivery_method, image_url, stock)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(guildId, sellerId, data.name, data.description, data.price, data.delivery, data.image, data.stock ?? -1);
}

function getProduct(id) {
  return db.prepare('SELECT * FROM products WHERE id = ?').get(id);
}

function updateProduct(id, data) {
  const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
  return db.prepare(`UPDATE products SET ${fields} WHERE id = ?`).run(...Object.values(data), id);
}

function getSellerProducts(sellerId, guildId) {
  return db.prepare('SELECT * FROM products WHERE seller_id = ? AND guild_id = ? AND status = "active"').all(sellerId, guildId);
}

// ===== Offers =====
function createOffer(guildId, sellerId, data) {
  const discount = data.originalPrice ? Math.round((1 - data.offerPrice / data.originalPrice) * 100) : null;
  return db.prepare(`
    INSERT INTO offers (guild_id, seller_id, title, description, original_price, offer_price, discount_percent, image_url, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(guildId, sellerId, data.title, data.description, data.originalPrice, data.offerPrice, discount, data.image, data.expiresAt);
}

// ===== Deals =====
function createDeal(guildId, productId, buyerId, sellerId, productName, price, ticketChannelId) {
  return db.prepare(`
    INSERT INTO deals (guild_id, product_id, buyer_id, seller_id, product_name, price, ticket_channel_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(guildId, productId, buyerId, sellerId, productName, price, ticketChannelId);
}

function getDeal(id) {
  return db.prepare('SELECT * FROM deals WHERE id = ?').get(id);
}

function getDealByTicket(channelId) {
  return db.prepare('SELECT * FROM deals WHERE ticket_channel_id = ?').get(channelId);
}

function closeDeal(dealId) {
  return db.prepare('UPDATE deals SET status = "completed", closed_at = CURRENT_TIMESTAMP WHERE id = ?').run(dealId);
}

// ===== Reviews =====
function createReview(guildId, dealId, reviewerId, sellerId, stars, comment) {
  db.prepare('INSERT INTO reviews (guild_id, deal_id, reviewer_id, seller_id, stars, comment) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, dealId, reviewerId, sellerId, stars, comment);
  db.prepare('UPDATE sellers SET rating_sum = rating_sum + ?, rating_count = rating_count + 1, total_sales = total_sales + 1 WHERE user_id = ? AND guild_id = ?')
    .run(stars, sellerId, guildId);
}

function getSellerRating(sellerId, guildId) {
  const seller = db.prepare('SELECT * FROM sellers WHERE user_id = ? AND guild_id = ?').get(sellerId, guildId);
  if (!seller || seller.rating_count === 0) return { avg: 0, count: 0, total_sales: 0 };
  return { avg: (seller.rating_sum / seller.rating_count).toFixed(1), count: seller.rating_count, total_sales: seller.total_sales };
}

// ===== Buyer Points =====
function addBuyerPoints(userId, guildId, points = 1) {
  const existing = db.prepare('SELECT * FROM buyer_points WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
  if (existing) {
    db.prepare('UPDATE buyer_points SET points = points + ?, total_deals = total_deals + 1 WHERE user_id = ? AND guild_id = ?').run(points, userId, guildId);
  } else {
    db.prepare('INSERT INTO buyer_points (user_id, guild_id, points, total_deals) VALUES (?, ?, ?, 1)').run(userId, guildId, points);
  }
  return db.prepare('SELECT * FROM buyer_points WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
}

function getBuyerPoints(userId, guildId) {
  return db.prepare('SELECT * FROM buyer_points WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
}

function getBuyerLeaderboard(guildId, limit = 10) {
  return db.prepare('SELECT * FROM buyer_points WHERE guild_id = ? ORDER BY points DESC LIMIT ?').all(guildId, limit);
}

// ===== Sellers =====
function registerSeller(userId, guildId, type = 'normal') {
  const existing = db.prepare('SELECT * FROM sellers WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
  if (!existing) {
    db.prepare('INSERT INTO sellers (user_id, guild_id, type) VALUES (?, ?, ?)').run(userId, guildId, type);
  } else {
    db.prepare('UPDATE sellers SET type = ? WHERE user_id = ? AND guild_id = ?').run(type, userId, guildId);
  }
}

function getSeller(userId, guildId) {
  return db.prepare('SELECT * FROM sellers WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
}

function isSeller(userId, guildId) {
  return !!getSeller(userId, guildId);
}

module.exports = {
  db,
  getUser, addXP, calculateXPNeeded, getLeaderboard,
  getShopConfig, setShopConfig,
  createProduct, getProduct, updateProduct, getSellerProducts,
  createOffer,
  createDeal, getDeal, getDealByTicket, closeDeal,
  createReview, getSellerRating,
  addBuyerPoints, getBuyerPoints, getBuyerLeaderboard,
  registerSeller, getSeller, isSeller,
};
