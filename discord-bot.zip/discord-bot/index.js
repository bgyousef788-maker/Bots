const { Client, GatewayIntentBits, Collection, ActivityType } = require('discord.js');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');
require('dotenv').config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

client.commands = new Collection();
client.cooldowns = new Collection();
client.musicQueues = new Map();

loadCommands(client);
loadEvents(client);

client.once('ready', () => {
  console.log(`✅ البوت شغال: ${client.user.tag}`);
  client.user.setActivity('سيرفرنا 🎮', { type: ActivityType.Watching });
});

client.login(process.env.TOKEN);
